#!/usr/bin/env bash
set -e
cd client
npm install
npm run build
cd ..
if [ ! -f capacitor.config.ts ]; then
  npx cap init StudyGenius com.himanshuraj.studygenuis --web-dir=client/dist
fi
if [ ! -d android ]; then
  npx cap add android
fi
npx cap copy
echo "Open Android Studio with: npx cap open android"
