# AI Study Helper - Design Guidelines

## Design Approach
**Selected System:** Material Design 3
**Justification:** Educational productivity tool requiring clear information hierarchy, familiar interaction patterns, and robust component system. Material 3's emphasis on dynamic theming and accessibility aligns with the light/dark mode requirement.

**Key Principles:**
- Clarity over decoration
- Consistent, predictable navigation
- Scannable content hierarchy
- Focused user flows for learning tasks

## Typography

**Font Family:** Roboto (via Google Fonts CDN)

**Scale:**
- Display: 32px/600 weight (screen titles)
- Headline: 24px/600 weight (section headers)
- Title: 20px/500 weight (card titles, dialog headers)
- Body Large: 16px/400 weight (primary content, chat messages)
- Body: 14px/400 weight (secondary text, descriptions)
- Label: 12px/500 weight (buttons, tabs, captions)

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16
- Micro spacing: 2, 4 (icon-text gaps, tight groups)
- Component padding: 4, 6 (cards, buttons)
- Section spacing: 8, 12 (between UI groups)
- Page margins: 16 (outer containers)

**Container Strategy:**
- Max-width: 1200px for main content
- Side padding: p-4 on mobile, p-8 on desktop
- Consistent vertical rhythm: space-y-6 for sections

## Component Library

### Navigation
**Top App Bar:**
- Height: 64px
- Contains: App title, back button (when applicable), settings icon
- Sticky positioning on scroll
- Elevation/shadow for depth

**Bottom Navigation (Mobile):**
- 4 items: Ask AI, Notes, Quiz, Settings
- Icons from Material Icons CDN
- Active state indicator with filled icons

### Cards
**Note Card:**
- Rounded corners (rounded-lg)
- Padding: p-6
- Content: Title (text-lg/font-medium), preview text (2 lines truncated), timestamp (text-sm/opacity-70)
- Actions: Delete icon (top-right), tap-to-open

**Quiz Question Card:**
- Similar styling to Note Card
- Radio buttons for MCQ options
- Submit/Next buttons at bottom

### Forms & Inputs
**Text Input:**
- Height: 56px for single-line, auto for multi-line
- Border radius: rounded-md
- Label: floating/above input
- Padding: px-4 py-3

**Chat Input (Ask AI):**
- Fixed bottom position
- Multi-line textarea with send button
- Max-height: 120px with scroll

### Buttons
**Primary Action:**
- Height: 48px
- Padding: px-6
- Rounded: rounded-full
- Font: 14px/600 weight
- Examples: Send message, Save note, Generate quiz

**Icon Buttons:**
- Size: 40x40px
- Rounded: rounded-full
- Examples: Delete, Back, Settings

### Lists
**Chat Messages:**
- User messages: Align right, max-width 75%
- AI responses: Align left, max-width 85%
- Spacing: gap-4 between messages
- Avatar/icon indicators for AI responses

**Notes List:**
- Grid: 1 column mobile, 2 columns tablet, 3 columns desktop
- Gap: gap-4
- Empty state: centered illustration with "No notes yet" text

## Screen-Specific Layouts

### Language Selection
- Centered content: max-w-md
- Logo/icon at top (margin-top: 20vh)
- Two large language cards (English/Hindi)
- Card size: min-height 120px, full-width buttons

### Home Dashboard
- Grid layout: 2x2 on mobile, 2x2 on tablet, 4x1 on desktop
- Each feature card: Icon (48px), title, brief description
- Padding: p-8 per card
- Hover elevation for interactivity

### Ask AI
- Chat container: flex-col with flex-1 for scrollable area
- Messages: padding p-4, space-y-4
- Input area: sticky bottom with backdrop blur
- "Save as Note" floating action button when AI responds

### Notes Detail View
- Full-screen modal/page
- Top bar: Back button, title, delete button
- Content area: p-6, prose formatting for long text
- Bottom action: "Generate Quiz from this Note" button

### Quiz Screen
- Question counter: "Question 2/5" at top
- Question card: centered, max-w-2xl
- Progress indicator: linear bar showing completion
- Results screen: Score display, option to retake or return home

### Settings
- List layout with dividers
- Sections: API Key, Theme, Language, About
- API Key input: password field with show/hide toggle
- Theme selector: Radio buttons (System/Light/Dark)
- "Made by Himanshu Raj" footer text

## Images
**No hero images required.** This is a utility application focused on functionality.

**Icons only:**
- Material Icons CDN for all UI icons
- App logo: Simple book/lightbulb combination (48x48px, displayed in language selection and app bar)
- Empty states: Simple line illustrations for empty notes/quiz lists

## Animations
**Minimal, purposeful only:**
- Page transitions: Simple fade (200ms)
- Card interactions: Subtle scale on tap (0.98)
- Loading states: Circular progress indicator for API calls
- No scroll-triggered or decorative animations