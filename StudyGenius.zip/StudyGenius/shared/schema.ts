import { z } from "zod";

// Note schema - represents a saved AI response
export const noteSchema = z.object({
  id: z.string(),
  title: z.string(),
  content: z.string(),
  createdAt: z.string(),
  language: z.enum(["en", "hi"]),
});

export const insertNoteSchema = noteSchema.omit({ id: true, createdAt: true });

export type Note = z.infer<typeof noteSchema>;
export type InsertNote = z.infer<typeof insertNoteSchema>;

// Chat message schema
export const chatMessageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string(),
});

export type ChatMessage = z.infer<typeof chatMessageSchema>;

// Quiz question schema
export const quizQuestionSchema = z.object({
  question: z.string(),
  options: z.array(z.string()).length(4),
  correctAnswer: z.number().min(0).max(3),
});

export const quizSchema = z.object({
  questions: z.array(quizQuestionSchema).length(5),
});

export type QuizQuestion = z.infer<typeof quizQuestionSchema>;
export type Quiz = z.infer<typeof quizSchema>;

// Settings schema
export const settingsSchema = z.object({
  theme: z.enum(["light", "dark", "system"]),
  language: z.enum(["en", "hi"]),
  apiKey: z.string().optional(),
});

export type Settings = z.infer<typeof settingsSchema>;

// API request/response schemas
export const chatRequestSchema = z.object({
  message: z.string().min(1),
  language: z.enum(["en", "hi"]),
  apiKey: z.string().optional(),
});

export const chatResponseSchema = z.object({
  response: z.string(),
});

export const quizRequestSchema = z.object({
  noteContent: z.string().min(10),
  language: z.enum(["en", "hi"]),
  apiKey: z.string().optional(),
});

export type ChatRequest = z.infer<typeof chatRequestSchema>;
export type ChatResponse = z.infer<typeof chatResponseSchema>;
export type QuizRequest = z.infer<typeof quizRequestSchema>;
