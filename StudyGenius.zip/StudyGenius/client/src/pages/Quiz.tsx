import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useApp } from "@/contexts/AppContext";
import { translations } from "@/lib/translations";
import { getNotes, getNote } from "@/lib/localStorage";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Quiz } from "@shared/schema";
import { ArrowLeft, Loader2, Trophy, BookOpen } from "lucide-react";

export default function QuizPage() {
  const [location, setLocation] = useLocation();
  const { language, settings } = useApp();
  const t = translations[language];
  const { toast } = useToast();

  const [notes] = useState(() => getNotes());
  const [selectedNoteId, setSelectedNoteId] = useState<string>("");
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    const params = new URLSearchParams(location.split("?")[1]);
    const noteId = params.get("noteId");
    if (noteId && getNote(noteId)) {
      setSelectedNoteId(noteId);
      generateQuizMutation.mutate(noteId);
    }
  }, [location]);

  const generateQuizMutation = useMutation({
    mutationFn: async (noteId: string) => {
      const note = getNote(noteId);
      if (!note) throw new Error("Note not found");
      
      const response = await apiRequest<Quiz>(
        "POST",
        "/api/quiz",
        { noteContent: note.content, language, apiKey: settings.apiKey }
      );
      return response;
    },
    onSuccess: (data) => {
      setQuiz(data);
      setCurrentQuestion(0);
      setSelectedAnswers([]);
      setShowResults(false);
      setScore(0);
    },
    onError: () => {
      toast({
        title: t.errorQuiz,
        variant: "destructive",
      });
    },
  });

  const handleGenerateQuiz = () => {
    if (!selectedNoteId) return;
    generateQuizMutation.mutate(selectedNoteId);
  };

  const handleAnswerSelect = (answer: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answer;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < 4) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handleFinish = () => {
    if (!quiz) return;
    
    let correctCount = 0;
    quiz.questions.forEach((question, index) => {
      if (selectedAnswers[index] === question.correctAnswer) {
        correctCount++;
      }
    });
    
    setScore(correctCount);
    setShowResults(true);
  };

  const handleTryAgain = () => {
    setCurrentQuestion(0);
    setSelectedAnswers([]);
    setShowResults(false);
    setScore(0);
    setQuiz(null);
    setSelectedNoteId("");
  };

  if (generateQuizMutation.isPending) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-8 max-w-md w-full mx-4">
          <div className="flex flex-col items-center gap-4">
            <Loader2 className="w-12 h-12 animate-spin text-primary" />
            <p className="text-foreground font-medium">{t.generating}</p>
          </div>
        </Card>
      </div>
    );
  }

  if (showResults && quiz) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="p-8 max-w-md w-full">
          <div className="text-center">
            <Trophy className="w-16 h-16 text-primary mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-foreground mb-2">
              {t.yourScore}
            </h2>
            <p className="text-4xl font-bold text-primary mb-6">
              {score} / 5
            </p>
            <p className="text-muted-foreground mb-6">
              {score === 5
                ? language === "en"
                  ? "Perfect! Excellent work!"
                  : "बिल्कुल सही! उत्कृष्ट काम!"
                : score >= 3
                ? language === "en"
                  ? "Good job! Keep learning!"
                  : "अच्छा काम! सीखते रहें!"
                : language === "en"
                ? "Keep practicing!"
                : "अभ्यास जारी रखें!"}
            </p>
            <div className="flex flex-col gap-3">
              <Button onClick={handleTryAgain} variant="outline" data-testid="button-try-again">
                {t.tryAgain}
              </Button>
              <Button onClick={() => setLocation("/home")} data-testid="button-home">
                {t.backToHome}
              </Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card px-4 py-3 flex items-center gap-4">
          <Button
            size="icon"
            variant="ghost"
            onClick={() => setLocation("/home")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-medium text-foreground">{t.quizTitle}</h1>
        </header>

        <main className="max-w-2xl mx-auto px-4 py-8">
          {notes.length === 0 ? (
            <div className="text-center py-12">
              <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-medium text-foreground mb-2">
                {t.noNotesForQuiz}
              </h3>
              <Button onClick={() => setLocation("/ask-ai")} className="mt-4">
                {t.askAI}
              </Button>
            </div>
          ) : (
            <Card className="p-6">
              <h3 className="text-lg font-medium text-foreground mb-4">
                {t.selectNote}
              </h3>
              <Select value={selectedNoteId} onValueChange={setSelectedNoteId}>
                <SelectTrigger data-testid="select-note">
                  <SelectValue placeholder={t.selectNote} />
                </SelectTrigger>
                <SelectContent>
                  {notes.map((note) => (
                    <SelectItem key={note.id} value={note.id}>
                      {note.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                onClick={handleGenerateQuiz}
                disabled={!selectedNoteId}
                className="w-full mt-4"
                data-testid="button-generate"
              >
                {t.generateQuiz}
              </Button>
            </Card>
          )}
        </main>
      </div>
    );
  }

  const question = quiz.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / 5) * 100;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card px-4 py-3">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-xl font-medium text-foreground">
              {t.question} {currentQuestion + 1} {t.of} 5
            </h1>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-8">
        <Card className="p-6 mb-6">
          <h2 className="text-lg font-medium text-foreground mb-6">
            {question.question}
          </h2>
          <RadioGroup
            value={selectedAnswers[currentQuestion]?.toString()}
            onValueChange={(value) => handleAnswerSelect(parseInt(value))}
          >
            <div className="space-y-3">
              {question.options.map((option, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-3 p-3 rounded-md border border-border hover-elevate cursor-pointer"
                  onClick={() => handleAnswerSelect(index)}
                >
                  <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                  <Label
                    htmlFor={`option-${index}`}
                    className="flex-1 cursor-pointer text-foreground"
                  >
                    {option}
                  </Label>
                </div>
              ))}
            </div>
          </RadioGroup>
        </Card>

        <div className="flex gap-3">
          {currentQuestion < 4 ? (
            <Button
              onClick={handleNext}
              disabled={selectedAnswers[currentQuestion] === undefined}
              className="flex-1"
              data-testid="button-next"
            >
              {t.next}
            </Button>
          ) : (
            <Button
              onClick={handleFinish}
              disabled={selectedAnswers[currentQuestion] === undefined}
              className="flex-1"
              data-testid="button-finish"
            >
              {t.finish}
            </Button>
          )}
        </div>
      </main>
    </div>
  );
}
