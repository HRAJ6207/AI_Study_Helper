import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useApp } from "@/contexts/AppContext";
import { translations } from "@/lib/translations";
import { getNotes, deleteNote as deleteNoteFromStorage } from "@/lib/localStorage";
import { useToast } from "@/hooks/use-toast";
import type { Note } from "@shared/schema";
import { ArrowLeft, Trash2, FileText, BookOpen } from "lucide-react";

export default function Notes() {
  const [, setLocation] = useLocation();
  const { language } = useApp();
  const t = translations[language];
  const { toast } = useToast();
  const [notes, setNotes] = useState<Note[]>([]);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [noteToDelete, setNoteToDelete] = useState<string | null>(null);

  useEffect(() => {
    setNotes(getNotes());
  }, []);

  const handleDeleteClick = (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setNoteToDelete(id);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (noteToDelete) {
      deleteNoteFromStorage(noteToDelete);
      setNotes(getNotes());
      toast({
        title: t.noteDeleted,
      });
    }
    setDeleteDialogOpen(false);
    setNoteToDelete(null);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat(language === "hi" ? "hi-IN" : "en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card px-4 py-3 flex items-center gap-4">
        <Button
          size="icon"
          variant="ghost"
          onClick={() => setLocation("/home")}
          data-testid="button-back"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-xl font-medium text-foreground">{t.notesTitle}</h1>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {notes.length === 0 ? (
          <div className="flex items-center justify-center min-h-[400px]">
            <div className="text-center">
              <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-medium text-foreground mb-2">{t.noNotes}</h3>
              <p className="text-muted-foreground mb-6">{t.noNotesDesc}</p>
              <Button onClick={() => setLocation("/ask-ai")} data-testid="button-start-chat">
                {t.askAI}
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {notes.map((note) => (
              <Link key={note.id} href={`/notes/${note.id}`}>
                <Card 
                  className="p-6 hover-elevate active-elevate-2 cursor-pointer transition-all h-full flex flex-col"
                  data-testid={`card-note-${note.id}`}
                >
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <FileText className="w-5 h-5 text-primary flex-shrink-0" />
                      <h3 className="font-medium text-foreground truncate">
                        {note.title}
                      </h3>
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="flex-shrink-0 h-8 w-8"
                      onClick={(e) => handleDeleteClick(note.id, e)}
                      data-testid={`button-delete-${note.id}`}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-3 mb-3 flex-1">
                    {note.content}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatDate(note.createdAt)}
                  </p>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </main>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t.confirmDelete}</AlertDialogTitle>
            <AlertDialogDescription>
              {t.confirmDelete}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">{t.cancel}</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              {t.delete}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
