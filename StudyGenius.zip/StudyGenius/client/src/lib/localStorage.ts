import type { Note, Settings } from "@shared/schema";

const NOTES_KEY = "ai_study_helper_notes";
const SETTINGS_KEY = "ai_study_helper_settings";
const LANGUAGE_KEY = "ai_study_helper_language";

// Notes storage
export const getNotes = (): Note[] => {
  try {
    const notes = localStorage.getItem(NOTES_KEY);
    return notes ? JSON.parse(notes) : [];
  } catch {
    return [];
  }
};

export const saveNote = (note: Note): void => {
  const notes = getNotes();
  notes.unshift(note);
  localStorage.setItem(NOTES_KEY, JSON.stringify(notes));
};

export const deleteNote = (id: string): void => {
  const notes = getNotes().filter((note) => note.id !== id);
  localStorage.setItem(NOTES_KEY, JSON.stringify(notes));
};

export const getNote = (id: string): Note | undefined => {
  return getNotes().find((note) => note.id === id);
};

// Settings storage
export const getSettings = (): Settings => {
  try {
    const settings = localStorage.getItem(SETTINGS_KEY);
    return settings
      ? JSON.parse(settings)
      : { theme: "system", language: "en" };
  } catch {
    return { theme: "system", language: "en" };
  }
};

export const saveSettings = (settings: Settings): void => {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
};

// Language preference (used before full settings are available)
export const getLanguagePreference = (): "en" | "hi" => {
  try {
    const lang = localStorage.getItem(LANGUAGE_KEY);
    return lang === "hi" ? "hi" : "en";
  } catch {
    return "en";
  }
};

export const saveLanguagePreference = (language: "en" | "hi"): void => {
  localStorage.setItem(LANGUAGE_KEY, language);
};

export const hasLanguagePreference = (): boolean => {
  return localStorage.getItem(LANGUAGE_KEY) !== null;
};
