export const translations = {
  en: {
    // Language Selection
    selectLanguage: "Select Your Language",
    english: "English",
    hindi: "हिंदी (Hindi)",

    // Home
    appName: "AI Study Helper",
    appTagline: "Your personal AI-powered learning companion",
    askAI: "Ask AI",
    askAIDesc: "Get explanations on any topic",
    notes: "My Notes",
    notesDesc: "View and manage saved notes",
    quiz: "Quiz",
    quizDesc: "Test your knowledge",
    settings: "Settings",
    settingsDesc: "Customize your experience",

    // Ask AI
    askAITitle: "Ask AI Anything",
    chatPlaceholder: "Ask about any topic you want to learn...",
    send: "Send",
    saveAsNote: "Save as Note",
    noteSaved: "Note saved successfully!",
    errorSaving: "Failed to save note",
    thinking: "AI is thinking...",
    errorChat: "Failed to get response. Please try again.",

    // Notes
    notesTitle: "My Notes",
    noNotes: "No notes yet",
    noNotesDesc: "Start chatting with AI and save responses as notes",
    delete: "Delete",
    confirmDelete: "Are you sure you want to delete this note?",
    cancel: "Cancel",
    noteDeleted: "Note deleted successfully",
    generateQuiz: "Generate Quiz from this Note",

    // Quiz
    quizTitle: "Quiz",
    selectNote: "Select a note to generate quiz",
    noNotesForQuiz: "You need at least one note to generate a quiz",
    generating: "Generating quiz questions...",
    question: "Question",
    of: "of",
    submit: "Submit Answer",
    next: "Next Question",
    finish: "Finish Quiz",
    yourScore: "Your Score",
    correct: "Correct",
    tryAgain: "Try Again",
    backToHome: "Back to Home",
    errorQuiz: "Failed to generate quiz. Please try again.",

    // Settings
    settingsTitle: "Settings",
    themeLabel: "Theme",
    light: "Light",
    dark: "Dark",
    system: "System",
    languageLabel: "Language",
    apiKeyLabel: "OpenAI API Key (Optional)",
    apiKeyPlaceholder: "sk-...",
    apiKeyHelp: "Enter your own API key or leave empty to use default",
    about: "About",
    madeBy: "Made with ❤️ by Himanshu Raj",
    version: "Version 1.0.0",
    save: "Save Settings",
    settingsSaved: "Settings saved successfully!",
  },
  hi: {
    // Language Selection
    selectLanguage: "अपनी भाषा चुनें",
    english: "English",
    hindi: "हिंदी (Hindi)",

    // Home
    appName: "AI स्टडी हेल्पर",
    appTagline: "आपका व्यक्तिगत AI-संचालित शिक्षण साथी",
    askAI: "AI से पूछें",
    askAIDesc: "किसी भी विषय पर स्पष्टीकरण प्राप्त करें",
    notes: "मेरे नोट्स",
    notesDesc: "सहेजे गए नोट्स देखें और प्रबंधित करें",
    quiz: "क्विज़",
    quizDesc: "अपने ज्ञान का परीक्षण करें",
    settings: "सेटिंग्स",
    settingsDesc: "अपने अनुभव को अनुकूलित करें",

    // Ask AI
    askAITitle: "AI से कुछ भी पूछें",
    chatPlaceholder: "जिस विषय के बारे में जानना चाहते हैं, उसके बारे में पूछें...",
    send: "भेजें",
    saveAsNote: "नोट के रूप में सहेजें",
    noteSaved: "नोट सफलतापूर्वक सहेजा गया!",
    errorSaving: "नोट सहेजने में विफल",
    thinking: "AI सोच रहा है...",
    errorChat: "प्रतिक्रिया प्राप्त करने में विफल। कृपया पुनः प्रयास करें।",

    // Notes
    notesTitle: "मेरे नोट्स",
    noNotes: "अभी तक कोई नोट नहीं",
    noNotesDesc: "AI के साथ चैट करना शुरू करें और उत्तरों को नोट्स के रूप में सहेजें",
    delete: "हटाएं",
    confirmDelete: "क्या आप वाकई इस नोट को हटाना चाहते हैं?",
    cancel: "रद्द करें",
    noteDeleted: "नोट सफलतापूर्वक हटाया गया",
    generateQuiz: "इस नोट से क्विज़ बनाएं",

    // Quiz
    quizTitle: "क्विज़",
    selectNote: "क्विज़ बनाने के लिए एक नोट चुनें",
    noNotesForQuiz: "क्विज़ बनाने के लिए आपको कम से कम एक नोट की आवश्यकता है",
    generating: "क्विज़ प्रश्न बना रहे हैं...",
    question: "प्रश्न",
    of: "में से",
    submit: "उत्तर जमा करें",
    next: "अगला प्रश्न",
    finish: "क्विज़ समाप्त करें",
    yourScore: "आपका स्कोर",
    correct: "सही",
    tryAgain: "पुनः प्रयास करें",
    backToHome: "होम पर वापस जाएं",
    errorQuiz: "क्विज़ बनाने में विफल। कृपया पुनः प्रयास करें।",

    // Settings
    settingsTitle: "सेटिंग्स",
    themeLabel: "थीम",
    light: "लाइट",
    dark: "डार्क",
    system: "सिस्टम",
    languageLabel: "भाषा",
    apiKeyLabel: "OpenAI API कुंजी (वैकल्पिक)",
    apiKeyPlaceholder: "sk-...",
    apiKeyHelp: "अपनी स्वयं की API कुंजी दर्ज करें या डिफ़ॉल्ट का उपयोग करने के लिए खाली छोड़ दें",
    about: "के बारे में",
    madeBy: "❤️ के साथ हिमांशु राज द्वारा बनाया गया",
    version: "संस्करण 1.0.0",
    save: "सेटिंग्स सहेजें",
    settingsSaved: "सेटिंग्स सफलतापूर्वक सहेजी गईं!",
  },
};

export type Language = keyof typeof translations;
export type TranslationKey = keyof typeof translations.en;
