// This app uses client-side localStorage for data persistence.
// No server-side storage is needed since all data (notes, settings, preferences)
// is stored in the browser's localStorage.

export interface IStorage {}

export class MemStorage implements IStorage {
  constructor() {}
}

export const storage = new MemStorage();
