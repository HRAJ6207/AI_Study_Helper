import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { chatRequestSchema, quizRequestSchema } from "@shared/schema";
import { generateTopicExplanation, generateQuizFromContent } from "./openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Chat endpoint - AI topic explanations
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, language, apiKey } = chatRequestSchema.parse(req.body);
      
      const response = await generateTopicExplanation(message, language, apiKey);
      
      res.json({ response });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      
      console.error("Chat error:", error);
      res.status(500).json({ 
        error: "Failed to generate response",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Quiz generation endpoint
  app.post("/api/quiz", async (req, res) => {
    try {
      const { noteContent, language, apiKey } = quizRequestSchema.parse(req.body);
      
      const quiz = await generateQuizFromContent(noteContent, language, apiKey);
      
      res.json(quiz);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      
      console.error("Quiz generation error:", error);
      res.status(500).json({ 
        error: "Failed to generate quiz",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
