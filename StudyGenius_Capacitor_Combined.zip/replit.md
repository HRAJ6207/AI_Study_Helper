# AI Study Helper

## Overview

AI Study Helper is an educational web application that helps students learn through AI-powered topic explanations, note-taking, and quiz generation. The application provides instant answers to learning questions, allows users to save responses as notes, and generates practice quizzes from saved content. It supports both English and Hindi languages with a Material Design 3 inspired interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server for fast hot module replacement
- Wouter for client-side routing (lightweight alternative to React Router)
- TanStack Query for server state management and API caching

**UI Component System**
- Shadcn/ui component library built on Radix UI primitives
- Tailwind CSS with custom design tokens following Material Design 3 principles
- Custom theming system supporting light, dark, and system-preferred modes
- Component configuration stored in components.json with path aliases for clean imports

**State Management Strategy**
- React Context API (AppContext) for global application state (language, theme, settings)
- Browser localStorage for client-side data persistence (notes, settings, preferences)
- No server-side database - all user data is stored locally in the browser
- TanStack Query handles server state for API interactions

**Design System**
- Material Design 3 principles with emphasis on clear information hierarchy
- Roboto font family loaded from Google Fonts CDN
- Consistent spacing using Tailwind's unit system (2, 4, 6, 8, 12, 16)
- Responsive layout with max-width of 1200px for main content
- Custom color system with HSL values supporting dynamic theming

### Backend Architecture

**Server Framework**
- Express.js handling HTTP requests and middleware
- TypeScript for type safety across the entire stack
- ESM module system for modern JavaScript practices

**API Design**
- RESTful endpoints for chat and quiz generation
- Request validation using Zod schemas defined in shared/schema.ts
- Centralized error handling with structured error responses
- Request logging middleware tracking API performance

**Code Organization**
- Shared schema definitions between client and server (shared/schema.ts)
- Separate route handlers (server/routes.ts) for maintainability
- OpenAI integration abstracted into dedicated module (server/openai.ts)
- Vite integration for development with HMR support

### Data Storage

**Client-Side Storage**
- All user data persists in browser's localStorage
- Notes stored as JSON arrays with id, title, content, createdAt, and language fields
- Settings stored separately including theme, language, and optional API key
- Language preference stored independently for early access before full settings load
- No server-side database required - fully client-side data architecture

**Storage Rationale**
- Simplifies deployment (no database provisioning needed)
- User data remains private and local
- Zero backend storage costs
- Instant data access without network requests
- Users can easily export/clear their data via browser tools

### External Dependencies

**OpenAI API Integration**
- GPT-5 model for generating topic explanations and quiz questions
- Two primary functions: generateTopicExplanation and generateQuizFromContent
- Support for both English and Hindi language outputs
- Optional user-provided API key stored in settings (falls back to server environment variable)
- JSON response format for structured quiz generation
- Error handling for API failures with user-friendly messages

**Third-Party Services**
- Google Fonts CDN for Roboto and Roboto Mono font families
- OpenAI API (requires OPENAI_API_KEY environment variable or user-provided key)

**UI Component Libraries**
- Radix UI primitives for accessible component foundations
- Embla Carousel for any carousel functionality
- Lucide React for consistent iconography
- cmdk for command menu patterns

**Development Tools**
- Drizzle Kit configured for PostgreSQL (config present but not actively used due to localStorage architecture)
- TypeScript for static type checking
- ESBuild for production bundling
- Replit-specific plugins for development environment integration

**Database Configuration Note**
- drizzle.config.ts and schema files exist for potential future PostgreSQL integration
- Currently not utilized as the app uses localStorage exclusively
- Configuration preserved for easy migration to server-side storage if needed