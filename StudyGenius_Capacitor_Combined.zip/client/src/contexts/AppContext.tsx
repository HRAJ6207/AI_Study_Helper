import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import { getSettings, saveSettings, getLanguagePreference, saveLanguagePreference } from "@/lib/localStorage";
import type { Settings } from "@shared/schema";
import type { Language } from "@/lib/translations";

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Settings["theme"];
  setTheme: (theme: Settings["theme"]) => void;
  settings: Settings;
  updateSettings: (settings: Partial<Settings>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<Settings>(() => getSettings());
  const [language, setLanguageState] = useState<Language>(() => getLanguagePreference());
  const [theme, setThemeState] = useState<Settings["theme"]>(() => settings.theme);

  // Apply theme to document
  useEffect(() => {
    const root = document.documentElement;
    
    if (theme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      root.classList.toggle("dark", systemTheme === "dark");
    } else {
      root.classList.toggle("dark", theme === "dark");
    }
  }, [theme]);

  // Listen for system theme changes
  useEffect(() => {
    if (theme !== "system") return;

    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
    const handleChange = (e: MediaQueryListEvent) => {
      document.documentElement.classList.toggle("dark", e.matches);
    };

    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, [theme]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    saveLanguagePreference(lang);
    const newSettings = { ...settings, language: lang };
    setSettings(newSettings);
    saveSettings(newSettings);
  };

  const setTheme = (newTheme: Settings["theme"]) => {
    setThemeState(newTheme);
    const newSettings = { ...settings, theme: newTheme };
    setSettings(newSettings);
    saveSettings(newSettings);
  };

  const updateSettings = (partial: Partial<Settings>) => {
    const newSettings = { ...settings, ...partial };
    setSettings(newSettings);
    saveSettings(newSettings);
    
    if (partial.theme) setThemeState(partial.theme);
    if (partial.language) setLanguageState(partial.language);
  };

  return (
    <AppContext.Provider value={{ language, setLanguage, theme, setTheme, settings, updateSettings }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within AppProvider");
  }
  return context;
}

export function useTranslation() {
  const { language } = useApp();
  return { language };
}
