import { useEffect, useState } from "react";
import { useRoute, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useApp } from "@/contexts/AppContext";
import { translations } from "@/lib/translations";
import { getNote } from "@/lib/localStorage";
import type { Note } from "@shared/schema";
import { ArrowLeft, Brain } from "lucide-react";

export default function NoteDetail() {
  const [, params] = useRoute("/notes/:id");
  const [, setLocation] = useLocation();
  const { language } = useApp();
  const t = translations[language];
  const [note, setNote] = useState<Note | null>(null);

  useEffect(() => {
    if (params?.id) {
      const foundNote = getNote(params.id);
      setNote(foundNote || null);
    }
  }, [params?.id]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat(language === "hi" ? "hi-IN" : "en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  };

  if (!note) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">Note not found</p>
          <Button onClick={() => setLocation("/notes")} className="mt-4">
            {t.backToHome}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card px-4 py-3 flex items-center gap-4">
        <Button
          size="icon"
          variant="ghost"
          onClick={() => setLocation("/notes")}
          data-testid="button-back"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-xl font-medium text-foreground truncate flex-1">
          {note.title}
        </h1>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6">
        <Card className="p-6 mb-6">
          <div className="mb-4">
            <p className="text-sm text-muted-foreground">
              {formatDate(note.createdAt)}
            </p>
          </div>
          <div className="prose prose-sm max-w-none dark:prose-invert">
            <p className="text-foreground whitespace-pre-wrap">{note.content}</p>
          </div>
        </Card>

        <Button
          onClick={() => setLocation(`/quiz?noteId=${note.id}`)}
          className="w-full"
          data-testid="button-generate-quiz"
        >
          <Brain className="w-5 h-5 mr-2" />
          {t.generateQuiz}
        </Button>
      </main>
    </div>
  );
}
