import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useApp } from "@/contexts/AppContext";
import { translations } from "@/lib/translations";
import { useToast } from "@/hooks/use-toast";
import type { Settings as SettingsType } from "@shared/schema";
import { ArrowLeft, Heart } from "lucide-react";

export default function Settings() {
  const [, setLocation] = useLocation();
  const { language, theme, settings, updateSettings, setLanguage, setTheme } = useApp();
  const t = translations[language];
  const { toast } = useToast();

  const [localSettings, setLocalSettings] = useState<SettingsType>(settings);

  const handleSave = () => {
    updateSettings(localSettings);
    if (localSettings.language !== language) {
      setLanguage(localSettings.language);
    }
    if (localSettings.theme !== theme) {
      setTheme(localSettings.theme);
    }
    toast({
      title: t.settingsSaved,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card px-4 py-3 flex items-center gap-4">
        <Button
          size="icon"
          variant="ghost"
          onClick={() => setLocation("/home")}
          data-testid="button-back"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-xl font-medium text-foreground">{t.settingsTitle}</h1>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6">
        <div className="space-y-6">
          <Card className="p-6">
            <div className="space-y-6">
              <div>
                <Label htmlFor="theme" className="text-base font-medium">
                  {t.themeLabel}
                </Label>
                <RadioGroup
                  value={localSettings.theme}
                  onValueChange={(value: SettingsType["theme"]) =>
                    setLocalSettings({ ...localSettings, theme: value })
                  }
                  className="mt-3 space-y-3"
                >
                  <div className="flex items-center space-x-3 p-3 rounded-md border border-border hover-elevate cursor-pointer">
                    <RadioGroupItem value="light" id="light" />
                    <Label htmlFor="light" className="flex-1 cursor-pointer">
                      {t.light}
                    </Label>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-md border border-border hover-elevate cursor-pointer">
                    <RadioGroupItem value="dark" id="dark" />
                    <Label htmlFor="dark" className="flex-1 cursor-pointer">
                      {t.dark}
                    </Label>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-md border border-border hover-elevate cursor-pointer">
                    <RadioGroupItem value="system" id="system" />
                    <Label htmlFor="system" className="flex-1 cursor-pointer">
                      {t.system}
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label htmlFor="language" className="text-base font-medium mb-3 block">
                  {t.languageLabel}
                </Label>
                <Select
                  value={localSettings.language}
                  onValueChange={(value: "en" | "hi") =>
                    setLocalSettings({ ...localSettings, language: value })
                  }
                >
                  <SelectTrigger id="language" data-testid="select-language">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="hi">हिंदी</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="apiKey" className="text-base font-medium">
                  {t.apiKeyLabel}
                </Label>
                <p className="text-sm text-muted-foreground mt-1 mb-3">
                  {t.apiKeyHelp}
                </p>
                <Input
                  id="apiKey"
                  type="password"
                  placeholder={t.apiKeyPlaceholder}
                  value={localSettings.apiKey || ""}
                  onChange={(e) =>
                    setLocalSettings({ ...localSettings, apiKey: e.target.value })
                  }
                  data-testid="input-api-key"
                />
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-base font-medium text-foreground mb-4">{t.about}</h3>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-red-500 fill-red-500" />
                {t.madeBy}
              </p>
              <p>{t.version}</p>
            </div>
          </Card>

          <Button onClick={handleSave} className="w-full" data-testid="button-save">
            {t.save}
          </Button>
        </div>
      </main>
    </div>
  );
}
