import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useApp } from "@/contexts/AppContext";
import { translations } from "@/lib/translations";
import { BookOpen, Languages } from "lucide-react";

export default function LanguageSelection() {
  const [, setLocation] = useLocation();
  const { setLanguage } = useApp();

  const handleLanguageSelect = (lang: "en" | "hi") => {
    setLanguage(lang);
    setLocation("/home");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary mb-4">
            <BookOpen className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-semibold text-foreground mb-2">
            AI Study Helper
          </h1>
          <p className="text-muted-foreground">
            {translations.en.selectLanguage}
          </p>
        </div>

        <div className="space-y-4">
          <Card 
            className="p-6 hover-elevate active-elevate-2 cursor-pointer transition-all"
            onClick={() => handleLanguageSelect("en")}
            data-testid="card-language-en"
          >
            <div className="flex items-center gap-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Languages className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-medium text-foreground">
                  {translations.en.english}
                </h3>
                <p className="text-sm text-muted-foreground">
                  Continue in English
                </p>
              </div>
            </div>
          </Card>

          <Card 
            className="p-6 hover-elevate active-elevate-2 cursor-pointer transition-all"
            onClick={() => handleLanguageSelect("hi")}
            data-testid="card-language-hi"
          >
            <div className="flex items-center gap-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Languages className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-medium text-foreground">
                  {translations.hi.hindi}
                </h3>
                <p className="text-sm text-muted-foreground">
                  हिंदी में जारी रखें
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
