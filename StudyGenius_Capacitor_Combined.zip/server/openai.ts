import OpenAI from "openai";

/*
Follow these instructions when using this blueprint:
1. Note that the newest OpenAI model is "gpt-5", not "gpt-4o" or "gpt-4". gpt-5 was released on August 7, 2025, after your knowledge cutoff. Always prefer using gpt-5 as it is the latest model. When copying code from this blueprint, ensure you also mention this information verbatim as a comment so that you don't revert it to older models: `// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user`
2. Use the response_format: { type: "json_object" } option
3. Request output in JSON format in the prompt
4. gpt-5 doesn't support temperature parameter, do not use it.
*/

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const MODEL = "gpt-5";

function getOpenAIClient(apiKey?: string): OpenAI {
  const key = apiKey || process.env.OPENAI_API_KEY;
  if (!key) {
    throw new Error("OpenAI API key is required. Please provide one in Settings or set OPENAI_API_KEY environment variable.");
  }
  return new OpenAI({ apiKey: key });
}

export async function generateTopicExplanation(
  topic: string,
  language: "en" | "hi",
  apiKey?: string
): Promise<string> {
  const openai = getOpenAIClient(apiKey);
  const systemPrompt =
    language === "hi"
      ? "आप एक सहायक AI शिक्षक हैं जो छात्रों को विषयों को समझने में मदद करते हैं। स्पष्ट, सरल और शैक्षिक व्याख्या प्रदान करें।"
      : "You are a helpful AI teacher that helps students understand topics. Provide clear, simple, and educational explanations.";

  const response = await openai.chat.completions.create({
    model: MODEL,
    messages: [
      {
        role: "system",
        content: systemPrompt,
      },
      {
        role: "user",
        content: topic,
      },
    ],
    max_completion_tokens: 2048,
  });

  return response.choices[0].message.content || "";
}

export async function generateQuizFromContent(
  content: string,
  language: "en" | "hi",
  apiKey?: string
): Promise<{
  questions: Array<{
    question: string;
    options: string[];
    correctAnswer: number;
  }>;
}> {
  const systemPrompt =
    language === "hi"
      ? `आप एक शैक्षिक प्रश्नोत्तरी जनरेटर हैं। दिए गए नोट सामग्री के आधार पर 5 बहुविकल्पीय प्रश्न बनाएं।
प्रत्येक प्रश्न में:
- एक स्पष्ट प्रश्न
- 4 विकल्प (A, B, C, D)
- सही उत्तर का इंडेक्स (0-3)

JSON प्रारूप में जवाब दें: { "questions": [{ "question": "...", "options": ["A", "B", "C", "D"], "correctAnswer": 0 }] }`
      : `You are an educational quiz generator. Create 5 multiple-choice questions based on the provided note content.
Each question should have:
- A clear question
- 4 options (A, B, C, D)
- The index of the correct answer (0-3)

Respond in JSON format: { "questions": [{ "question": "...", "options": ["A", "B", "C", "D"], "correctAnswer": 0 }] }`;

  const userPrompt =
    language === "hi"
      ? `इस सामग्री से 5 MCQ प्रश्न बनाएं:\n\n${content}`
      : `Generate 5 MCQ questions from this content:\n\n${content}`;

  const openai = getOpenAIClient(apiKey);
  const response = await openai.chat.completions.create({
    model: MODEL,
    messages: [
      {
        role: "system",
        content: systemPrompt,
      },
      {
        role: "user",
        content: userPrompt,
      },
    ],
    response_format: { type: "json_object" },
    max_completion_tokens: 2048,
  });

  const result = JSON.parse(response.choices[0].message.content || "{}");
  return result;
}
