import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json());

app.post('/api/ask', async (req, res) => {
  const { question } = req.body;
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: question }],
      temperature: 0.2,
      max_tokens: 500
    })
  });
  const data = await response.json();
  res.json(data);
});

app.post('/api/quiz', async (req, res) => {
  const { note } = req.body;
  const prompt = `Create 5 MCQs based on this note. Return JSON array.`;
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: prompt + note }],
      temperature: 0.2,
      max_tokens: 700
    })
  });
  const data = await response.json();
  res.json(data);
});

app.listen(process.env.PORT || 8080, () => console.log('API running'));
